export {
  agentCoreControllerBasePath,
  agentCoreRoutes,
  getAgentCoreRouteMethod,
  getAgentCoreRoutePath,
  getAgentCoreRouteSegment,
}
  from "@easymo/commons";

export type { AgentCoreRouteKey } from "@easymo/commons";
