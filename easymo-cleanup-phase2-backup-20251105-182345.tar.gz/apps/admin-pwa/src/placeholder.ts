// Placeholder entry point so TypeScript project references remain valid.
export const adminPwaStranglerReady = true;
