# Admin PWA (Strangler Fig)

This placeholder captures the future progressive web app that will replace pieces of [`../../admin-app`](../../admin-app) incrementally.

The goal is to carve new admin workflows out of the legacy React bundle without forcing a big bang migration. New screens should live here and be bridged back into the existing routing shell until the full cut-over is complete.
