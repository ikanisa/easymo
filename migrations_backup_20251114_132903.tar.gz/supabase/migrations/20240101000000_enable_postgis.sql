-- Enable PostGIS before any geography columns are created
CREATE EXTENSION IF NOT EXISTS postgis;
