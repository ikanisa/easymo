BEGIN;
-- Placeholder so local migration directory matches remote version 20251031203000
-- No-op: the actual migration already exists on the remote database.
COMMIT;
