-- Enable PostGIS for geography/geometry support used by Phase 2 agents
CREATE EXTENSION IF NOT EXISTS postgis;
