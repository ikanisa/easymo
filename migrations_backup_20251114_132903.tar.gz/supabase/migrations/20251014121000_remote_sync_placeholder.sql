BEGIN;
-- Placeholder so local migrations match remote version 20251014121000.
-- Original file disabled; will be re-implemented later if needed.
COMMIT;
