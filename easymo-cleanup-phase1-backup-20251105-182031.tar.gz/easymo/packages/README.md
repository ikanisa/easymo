Shared code lives here.
