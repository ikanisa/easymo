# Docs

- `DECISIONS.md` – list of ADRs
- `ADR_TEMPLATE.md` – copy this when adding a new decision
