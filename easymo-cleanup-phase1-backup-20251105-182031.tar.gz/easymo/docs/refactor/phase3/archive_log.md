# Archived WA flows

| File                      | Notes                                                             |
| ------------------------- | ----------------------------------------------------------------- |
| `flow.admin.insurance.v1` | Deprecated insurance admin flow (migrated to archive 2025-09-25). |
| `insurance/ocr.ts`        | Legacy OCR-based insurance ingestion flow (deprecated).           |
