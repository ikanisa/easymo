# ADR: <title>

## Context

<why are we doing this?>

## Decision

<what we decided>

## Consequences

<good/bad effects>

## Links

<PRs, issues, refs>
