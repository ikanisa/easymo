Safety rules go here.
