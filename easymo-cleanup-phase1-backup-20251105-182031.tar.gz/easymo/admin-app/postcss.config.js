/** Next.js + Tailwind: PostCSS config (string plugin names, not require()) */
module.exports = {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
};
