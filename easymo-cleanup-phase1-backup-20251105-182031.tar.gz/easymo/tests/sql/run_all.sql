-- Convenience runner to execute all SQL regression scripts
\ir claim_notifications.sql
\ir promote_draft_menu.sql
\ir matching_v2.sql
