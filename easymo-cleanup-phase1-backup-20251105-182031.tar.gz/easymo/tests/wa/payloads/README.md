Sample inbound payloads for local testing. Use with `tests/wa/runbook.md` when
replaying events against the `wa-webhook` Edge Function.
